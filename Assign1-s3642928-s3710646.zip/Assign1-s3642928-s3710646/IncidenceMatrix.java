
import java.io.*;
import java.util.*;

/**
 * Incident matrix implementation for the AssociationGraph interface.
 *
 * Your task is to complete the implementation of this class. You may add
 * methods, but ensure your modified class compiles and runs.
 *
 * @author Yi Weng / XinHong Chen, 2019.
 */
public class IncidenceMatrix extends AbstractAssocGraph {

	/**
	 * this stores the edges name as the first row of the matrix, store source name
	 * at first position, store Target name at second position.
	 */

	// map store the label of verts and edges and their index
	private Map<String, Integer> verts;
	private Map<String, Integer> edges;
	// rows are verts, columns are edges
	private int[][] myMatrix;

	/**
	 * Contructs empty graph.
	 */
	public IncidenceMatrix() {
		this.verts = new HashMap<>();
		this.edges = new HashMap<>();
		this.myMatrix = new int[1][1];
	} // end of IncidentMatrix()

	public void addVertex(String vertLabel) {

		// extend matrix
		int index = this.myMatrix.length;
		int[][] m = new int[this.myMatrix.length + 1][this.myMatrix[0].length];
		for (int i = 0; i < this.myMatrix.length; i++) {
			System.arraycopy(this.myMatrix[i], 0, m[i], 0, this.myMatrix[i].length);
		}
		this.myMatrix = m;
		// use row number for vertex index
		this.verts.put(vertLabel, index);
	} // end of addVertex()

	public void addEdge(String srcLabel, String tarLabel, int weight) {

		try {
			// check node if exists
			if (!verts.containsKey(srcLabel) || !verts.containsKey(tarLabel))
				throw new IOException();
			String edge = srcLabel + "-" + tarLabel;
			// check edge if exists
			if (edges.containsKey(edge))
				throw new IOException();
			// use column number for edge index
			int indexE = this.myMatrix[0].length;
			this.edges.put(edge, indexE);
			// extend matrix
			int[][] m = new int[this.myMatrix.length][this.myMatrix[0].length + 1];
			for (int i = 0; i < this.myMatrix.length; i++) {
				System.arraycopy(this.myMatrix[i], 0, m[i], 0, this.myMatrix[i].length);
			}
			this.myMatrix = m;
			// add value for source with weight in matrix
			this.myMatrix[this.verts.get(srcLabel)][indexE] = weight;
			// add value for target with negative weight in matrix
			this.myMatrix[this.verts.get(tarLabel)][indexE] = -weight;
			// implementation column number
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}

	} // end of addEdge()

	public int getEdgeWeight(String srcLabel, String tarLabel) {

		try {
			// check node if exists
			String edge;
			if (!this.verts.containsKey(srcLabel) || !this.verts.containsKey(tarLabel))
				throw new IOException("This vertex is not existing: " + srcLabel + "-" + tarLabel);
			// check edge if exists
			// check if A-B
			if (this.edges.containsKey((edge = srcLabel + "-" + tarLabel))) {
				int indexE = this.edges.get(edge);
				int indexV = this.verts.get(srcLabel);
				int weight = this.myMatrix[indexV][indexE];
				return weight;
			}
			throw new IOException("This edge is not existing: " + srcLabel + "-" + tarLabel);
		} catch (IOException e) {
			System.out.println(e.getMessage());
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		// update return value
		return EDGE_NOT_EXIST;
	} // end of getEdgeWeight()

	public void updateWeightEdge(String srcLabel, String tarLabel, int weight) {

		String edge = "";
		int indexE = -1;
		int indexVsrc = -1;
		int indexVtar = -1;
		// give index
		try {
			if (this.edges.containsKey((edge = srcLabel + "-" + tarLabel))) {
				indexE = this.edges.get(edge);
				indexVsrc = this.verts.get(srcLabel);
				indexVtar = this.verts.get(tarLabel);
			} else
				throw new IOException("There is no such edge");
			// delete index and value
			if (weight == 0) {
				int[][] m = new int[this.myMatrix.length][this.myMatrix[0].length - 1];
				int oldi = 0;
				int oldj = 0;
				// build new matrix
				for (int i = 0; i < m.length; oldi++, i++) {
					oldj = 0;
					for (int j = 0; j < m[i].length; oldj++, j++) {
						if (j == this.edges.get(edge))
							oldj++;
						m[i][j] = this.myMatrix[oldi][oldj];
					}
				}
				this.myMatrix = m;
				Iterator<String> it = this.edges.keySet().iterator();
				// build new edges index map
				while (it.hasNext()) {
					String key = it.next();
					int value = this.edges.get(key);

					// move index of edge to previous position
					if (value > this.edges.get(edge))
						value--;
					this.edges.put(key, value);
				}
				this.edges.remove(edge);

			} else {
				this.myMatrix[indexVsrc][indexE] = weight;
				this.myMatrix[indexVtar][indexE] = -weight;
			}
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
	} // end of updateWeightEdge()

	public void removeVertex(String vertLabel) {

		try {
			if (!this.verts.containsKey(vertLabel))
				throw new IOException("This vertex is not existing: " + vertLabel);
			int a = this.verts.get(vertLabel);
			// get the list what we want to delete
			MyLinkedList<Integer> list = new MyLinkedList<>();
			for (int i = 0; i < this.myMatrix[a].length; i++) {
				if (this.myMatrix[a][i] != 0)
					list.add(i);
			}
			int[][] m = new int[this.myMatrix.length - 1][this.myMatrix[0].length - list.size()];
			int oldi = 0;
			int oldj = 0;
			// build new matrix
			for (int i = 0; i < m.length; oldi++, i++) {

				int indexOfList = 0;
				oldj = 0;
				if (i == a)
					oldi++;
				for (int j = 0; j < m[i].length; oldj++, j++) {
					int num = -1;
					if (indexOfList < list.size())
						num = list.get(indexOfList);
					if (oldj == num) {
						indexOfList++;
						oldj++;
					}
					m[i][j] = this.myMatrix[oldi][oldj];
				}
			}
			this.myMatrix = m;

			Iterator<String> it = this.edges.keySet().iterator();
			// build new edges index
			while (it.hasNext()) {
				String key = it.next();
				int value = this.edges.get(key);
				// can find in delete list

				if (list.indexOf(value) != -1) {
					// move row index
					it.remove();
				} else {
					for (int i = 0; i < list.size(); i++) {
						// move index of edge to previous position
						if (value >= list.get(i))
							value--;
					}
					this.edges.put(key, value);
				}
			}

			// build new vertex index
			it = this.verts.keySet().iterator();
			while (it.hasNext()) {
				String key = it.next();
				int value = this.verts.get(key);
				// move index of edge to previous position
				if (value > a)
					value--;
				this.verts.put(key, value);
			}
			this.verts.remove(vertLabel);
		} catch (IOException e) {
			System.out.println(e.getMessage());
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	} // end of removeVertex()

	public List<MyPair> inNearestNeighbours(int k, String vertLabel) {

		List<MyPair> neighbours = new ArrayList<MyPair>();
		try {
			if (k == -1)
				// print all existing edge
				neighbours = findAllInEdges(vertLabel);
			else if (k > 0)
				// print k-nearest existing edge
				neighbours = findMins(k, vertLabel);
			else
				throw new IOException("Invalid input");
		} catch (IOException e) {
			System.out.println(e.getMessage());
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return neighbours;
	} // end of inNearestNeighbours()

	public List<MyPair> outNearestNeighbours(int k, String vertLabel) {
		List<MyPair> neighbours = new ArrayList<MyPair>();
		try {
			if (k == -1)
				// print all existing edge
				neighbours = findAllOutEdges(vertLabel);
			else if (k > 0)
				// print k-nearest existing edge
				neighbours = findMaxs(k, vertLabel);
			else {
				System.out.println(vertLabel);
				throw new IOException("Invalid input");
			}
		} catch (IOException e) {
			System.out.println(e.getMessage());
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return neighbours;
	} // end of outNearestNeighbours()

	public void printVertices(PrintWriter os) {

		String content = "";
		for (String e : this.verts.keySet()) {
			content = e + " ";
			os.print(content);
			os.flush();
		}
	} // end of printVertices()

	public void printEdges(PrintWriter os) {

		String content = "";
		try {
			Iterator<String> it = this.edges.keySet().iterator();
			while (it.hasNext()) {
				String str = it.next();
				String[] key = str.split("-");
				String source = key[0];
				String target = key[1];
				int weight = this.myMatrix[this.verts.get(source)][this.edges.get(str)];
				content = source + " " + target + " " + weight + "\n";
				os.printf(content);
				os.flush();
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	} // end of printEdges()

	private List<MyPair> findAllInEdges(String vertLabel) throws Exception {
		List<MyPair> neighbours = new ArrayList<MyPair>();
		Iterator<String> it = this.edges.keySet().iterator();
		while (it.hasNext()) {
			String str = it.next();
			String[] key = str.split("-");
			// find target edges
			if (key[1].equals(vertLabel)) {
				int weight = this.myMatrix[this.verts.get(key[0])][this.edges.get(str)];
				neighbours.add(new MyPair(key[0], weight));
			}
		}
		return neighbours;
	}// end of findAllInEdges()

	private List<MyPair> findAllOutEdges(String vertLabel) throws Exception {
		List<MyPair> neighbours = new ArrayList<MyPair>();
		Iterator<String> it = this.edges.keySet().iterator();
		while (it.hasNext()) {
			String str = it.next();
			String[] key = str.split("-");
			// find target edges
			if (key[0].equals(vertLabel)) {
				int weight = this.myMatrix[this.verts.get(key[0])][this.edges.get(str)];
				neighbours.add(new MyPair(key[1], weight));
			}
		}
		return neighbours;
	}// end of findAllOutEdges()

	private List<MyPair> findMins(int k, String vertLabel) throws Exception {
		List<MyPair> neighbours = new ArrayList<MyPair>();
		Iterator<String> it = this.edges.keySet().iterator();
		Map<String, Integer> map = new HashMap<>();
		// find edge map
		while (it.hasNext()) {
			String str = it.next();
			String[] key = str.split("-");
			// find target edges
			if (key[1].equals(vertLabel)) {
				int weight = this.myMatrix[this.verts.get(key[1])][this.edges.get(str)];
				map.put(key[0], weight);
			}
		}
		// find min nearest neighbours
		it = map.keySet().iterator();
		while (k != 0) {
			int min = 0;
			String str = "";
			while (it.hasNext()) {
				str = it.next();
				int a = 0;
				if ((a = map.get(str)) < min)
					min = a;
			}
			neighbours.add(new MyPair(str, Math.abs(min)));
			k--;
		}
		return neighbours;
	}// end of findMins()

	private List<MyPair> findMaxs(int k, String vertLabel) throws Exception {
		List<MyPair> neighbours = new ArrayList<MyPair>();
		Iterator<String> it = this.edges.keySet().iterator();
		Map<String, Integer> map = new HashMap<>();
		// find edge map
		while (it.hasNext()) {
			String str = it.next();
			String[] key = str.split("-");
			// find target edges
			if (key[0].equals(vertLabel)) {
				int weight = this.myMatrix[this.verts.get(key[0])][this.edges.get(str)];
				map.put(key[1], weight);
			}
		}
		// find min nearest neighbours
		it = map.keySet().iterator();
		while (k != 0) {
			int max = 0;
			String str = "";
			while (it.hasNext()) {
				str = it.next();
				int a = 0;
				if ((a = map.get(str)) > max)
					max = a;
			}
			neighbours.add(new MyPair(str, max));
			k--;
		}
		return neighbours;
	}// end of findMaxs()
		// MyLinkedList is a generic list collection

	protected class MyLinkedList<E> {

		private Node<E> first;
		private Node<E> last;
		private int size;

		// construct a new MyLinkedList with 0 size
		public MyLinkedList() {
			this.size = 0;
		}

		public E remove(E e) throws IOException {
			// get node from element
			Node<E> node = nodeOf(e);
			// remove this node from list
			return unlink(node);
		}

		public int size() {
			return this.size;
		}
		// end constructor

		public void add(E element) {
			// add to the end of linked list
			linkLast(element);
		}

		private void linkLast(E e) {
			final Node<E> last = this.last;
			final Node<E> newNode = new Node<>(last, e, null);
			if (last == null)
				this.first = newNode;
			else
				last.next = newNode;
			this.last = newNode;
			this.size++;
		}

		public E get(int index) throws Exception {
			checkElementIndex(index);
			return node(index).item;
		}

		// find node from index
		private Node<E> node(int index) {
			// beginning at head
			if (index < (this.size / 2)) {
				Node<E> node = this.first;
				for (int i = 0; i < index; i++)
					node = node.next;
				return node;
			} else {
				// beginning at tail
				Node<E> node = this.last;
				for (int i = this.size - 1; i > index; i--)
					node = node.prev;
				return node;
			}
		}

		// set value to the node
		public E set(int index, E element) throws Exception {
			checkElementIndex(index);
			Node<E> node = node(index);
			E old = node.item;
			node.item = element;
			return old;
		}

		public E remove(int index) throws Exception {
			checkElementIndex(index);
			// find node from index and remove it
			return unlink(node(index));
		}

		public int indexOf(E e) throws IOException {
			Node<E> node = this.first;
			for (int i = 0; i < this.size; i++) {
				if (node.item.equals(e))
					return i;
				node = node.next;
			}
			return -1;
		}// end of indexOf()

		public Node<E> nodeOf(E e) throws IOException {
			Node<E> node = this.first;
			for (int i = 0; i < this.size; i++) {
				if (node.item.equals(e))
					return node;
				node = node.next;
			}
			throw new IOException();
		}// end of nodeOf()

		// remove link of the node
		E unlink(Node<E> e) {
			final E element = e.item;
			final Node<E> next = e.next;
			final Node<E> prev = e.prev;

			// if it is the first node
			if (prev == null) {
				this.first = next;
				next.prev = null;
			}
			// if it is the last node
			else if (next == null) {
				last = prev;
				prev.next = null;
			}
			// if it is in the middle
			else {
				prev.next = next;
				next.prev = prev;
			}
			this.size--;
			return element;
		}

		public void checkElementIndex(int index) throws Exception {
			if (index < 0) {
				throw new IllegalArgumentException("Index can not be negative.");
			} else if (index >= this.size) {
				throw new IndexOutOfBoundsException("Out of bounds.");
			}
		}

		@SuppressWarnings("hiding")
		private class Node<E> {
			E item;// data of current node
			Node<E> next;
			Node<E> prev;

			Node(Node<E> prev, E element, Node<E> next) {
				this.item = element;
				this.next = next;
				this.prev = prev;
			}
		}
	}// end of class MyLinkedList

} // end of class IncidenceMatrix
