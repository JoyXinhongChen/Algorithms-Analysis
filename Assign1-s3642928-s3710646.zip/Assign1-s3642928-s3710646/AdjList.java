
import java.io.*;
import java.util.*;

/**
 * Adjacency list implementation for the AssociationGraph interface.
 *
 * Your task is to complete the implementation of this class. You may add
 * methods, but ensure your modified class compiles and runs.
 *
 * @author Yi Weng / XinHong Chen, 2019.
 */
public class AdjList extends AbstractAssocGraph {

	private MyLinkedList<Vertex> nodes;

	/**
	 * Contructs empty graph.
	 */
	public AdjList() {
		// Implement me!
		this.nodes = new MyLinkedList<>();
	} // end of AdjList()

	public void addVertex(String vertLabel) {
		// Implement me!
		Vertex node = new Vertex(vertLabel);
		nodes.add(node);
	} // end of addVertex()

	public void addEdge(String srcLabel, String tarLabel, int weight) {
		// Implement me!

		try {
			Vertex source = findVertex(srcLabel);
			source.addEdge(tarLabel, weight);
		} catch (IOException e) {
			System.out.println(e.getMessage());
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	} // end of addEdge()

	public int getEdgeWeight(String srcLabel, String tarLabel) {
		// Implement me!

		try {
			// find node
			Vertex source = findVertex(srcLabel);
			int weight = source.getWeight(tarLabel);
			return weight;
		} catch (IOException e) {
			System.out.println(e.getMessage());
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		// update return value
		return EDGE_NOT_EXIST;
	} // end of existEdge()

	public void updateWeightEdge(String srcLabel, String tarLabel, int weight) {
		// Implement me!

		try {
			Vertex source = findVertex(srcLabel);
			// when input is 0, then remove edge from both sides
			if (weight == 0) {
				source.remove(tarLabel);
			} else {
				// update weight from both sides
				source.setWeight(tarLabel, weight);
			}
		} catch (IOException e) {
			System.out.println(e.getMessage());
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	} // end of updateWeightEdge()

	public void removeVertex(String vertLabel) {
		// Implement me!
		Vertex target = null;
		try {
			Vertex vert = findVertex(vertLabel);
			// remove node
			this.nodes.remove(vert);
			// remove edges
			for (int i = 0; i < this.nodes.size(); i++) {
				// from source neighbour list to find target and delete edge from opposite end
				target = this.nodes.get(i);
				int length = target.getMylist().size();
				int j = 0;
				while (j < length) {
					if (target.getMylist().get(j).equals(vertLabel)) {
						target.remove(vertLabel);
						j--;
						length--;
					}
					j++;
				}
			}
		} catch (IOException e) {
			System.out.println(e.getMessage());
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	} // end of removeVertex()

	public List<MyPair> inNearestNeighbours(int k, String vertLabel) {
		List<MyPair> neighbours = new ArrayList<MyPair>();

		// Implement me!
		try {
			int i = 0;
			if (k == -1) {
				while (i < this.nodes.size()) {
					int length = this.nodes.get(i).getMylist().size();
					for (int j = 0; j < length; j++) {
						if (this.nodes.get(i).getMylist().get(j).equals(vertLabel))
							neighbours.add(
									new MyPair(this.nodes.get(i).getlabel(), this.nodes.get(i).getWeights().get(j)));
					}
					i++;
				}
			} else if (k > 0) {
				i = 0;
				MyLinkedList<Integer> list = new MyLinkedList<>();
				MyLinkedList<String> listLabel = new MyLinkedList<>();

				while (i < this.nodes.size()) {
					int length = this.nodes.get(i).getMylist().size();
					String label = this.nodes.get(i).getlabel();
					for (int j = 0; j < length; j++) {
						int value = this.nodes.get(i).getWeights().get(j);
						if (this.nodes.get(i).getMylist().get(j).equals(vertLabel)) {
							list.add(value);
							listLabel.add(label);
						}
					}
					i++;
				}
				int length = list.size();
				while (k != 0) {
					int max = 0;
					int index = -1;
					for (i = 0; i < length; i++) {
						if (list.get(i) > max) {
							max = list.get(i);
							index = i;
						}
					}
					if (index == -1)
						break;
					neighbours.add(new MyPair(listLabel.get(index), list.get(index)));
					list.remove(index);
					listLabel.remove(index);
					length = list.size();
					k--;
				}
			}
		} catch (IOException e) {
			System.out.println(e.getMessage());
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return neighbours;
	} // end of inNearestNeighbours()

	public List<MyPair> outNearestNeighbours(int k, String vertLabel) {
		List<MyPair> neighbours = new ArrayList<MyPair>();
		// Implement me!
		try {
			Vertex vert = findVertex(vertLabel);
			String label = "";
			int value = 0;
			if (k == -1) {
				for (int i = 0; i < vert.getMylist().size(); i++) {
					label = vert.getMylist().get(i);
					value = vert.getWeights().get(i);
					neighbours.add(new MyPair(label, value));
				}
			} else if (k > 0) {

				MyLinkedList<Integer> list = new MyLinkedList<>();
				MyLinkedList<String> listLabel = new MyLinkedList<>();
				for (int i = 0; i < vert.getMylist().size(); i++) {
					label = vert.getMylist().get(i);
					value = vert.getWeights().get(i);
					list.add(value);
					listLabel.add(label);
				}
				int length = list.size();
				while (k != 0) {
					int max = 0;
					int index = -1;
					for (int i = 0; i < length; i++) {
						if (list.get(i) > max) {
							max = list.get(i);
							index = i;
						}
					}
					if (index == -1)
						break;
					neighbours.add(new MyPair(listLabel.get(index), list.get(index)));
					list.remove(index);
					listLabel.remove(index);
					length = list.size();
					k--;
				}
			}
		} catch (

		IOException e) {
			System.out.println(e.getMessage());
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return neighbours;
	} // end of outNearestNeighbours()

	public void printVertices(PrintWriter os) {
		// Implement me!

		try {
			String content = "";
			if (this.nodes.size() == 0)
				throw new IOException();
			for (int i = 0; i < nodes.size(); i++) {
				Vertex vert = nodes.get(i);
				content = vert.getlabel() + " ";
				os.print(content);
				os.flush();
			}
		} catch (IOException e) {
			System.out.println(e.getMessage());
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	} // end of printVertices()

	public void printEdges(PrintWriter os) {
		// Implement me!

		try {
			String content = "";
			if (this.nodes.size() == 0)
				throw new IOException();
			for (int i = 0; i < this.nodes.size(); i++) {
				content = nodes.get(i).printMyEdges();
				os.printf(content);
				os.flush();
			}
		} catch (IOException e) {
			System.out.println(e.getMessage());
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	} // end of printEdges()

	public Vertex findVertex(String label) throws Exception {
		for (int i = 0; i < this.nodes.size(); i++) {
			if ((this.nodes.get(i)).getlabel().equals(label))
				return this.nodes.get(i);
		}
		throw new IOException();
	}// end of indexFromLabel()

	// inner class Vertex
	protected class Vertex {

		private String label;
		private MyLinkedList<String> mylist;
		private MyLinkedList<Integer> weights;

		// constructor
		public Vertex(String label) {
			this.label = label;
			// label list
			this.mylist = new MyLinkedList<>();
			this.weights = new MyLinkedList<>();
		}
		// end constructor

		public MyLinkedList<Integer> getWeights() {
			return this.weights;
		}

		public String toString() {
			return this.label;
		}

		public void setWeight(String vertLabel, int weight) throws Exception {
			// if this edge exist
			if (mylist.indexOf(vertLabel) != -1) {
				int i = mylist.indexOf(vertLabel);
				// set its weight for weight list
				this.weights.set(i, weight);
			} else
				// if this label does not exists then throw IOException
				throw new IOException("There is not a such edge existing " + vertLabel + " " + weight);
		}

		public int getWeight(String tarLabel) throws IOException, Exception {
			int weight = -1;
			if ((weight = this.weights.get(this.mylist.indexOf(tarLabel))) != 0)
				return weight;
			return weight;
		}

		private String getlabel() {
			return this.label;
		}

		public MyLinkedList<String> getMylist() {
			return this.mylist;
		}

		// remove an edge for this node
		private void remove(String vertLabel) throws Exception {
			// remove a label for list
			int i = mylist.indexOf(vertLabel);
			this.mylist.remove(i);
			// remove its weight for list
			this.weights.remove(i);

		}

		private void addEdge(String vertLabel, int weight) throws Exception {
			if (mylist.indexOf(vertLabel) == -1) {
				// add a label for label list
				this.mylist.add(vertLabel);
				// add its weight for weight list
				this.weights.add(weight);
			} else
				// if this label exists throw IOException
				throw new IOException();
		}

		public String printMyEdges() throws Exception {
			String content = "";
			for (int i = 0; i < this.mylist.size(); i++) {
				if (this.weights.get(i) > 0)
					content += this.label + " " + this.mylist.get(i) + " " + this.weights.get(i) + "\n";
			}
			return content;
		}

	}// end of class Vertex

	// MyLinkedList is a generic list collection
	protected class MyLinkedList<E> {

		private Node<E> first;
		private Node<E> last;
		private int size;

		// construct a new MyLinkedList with 0 size
		public MyLinkedList() {
			this.size = 0;
		}

		public E remove(E e) throws IOException {
			// get node from element
			Node<E> node = nodeOf(e);
			// remove this node from list
			return unlink(node);
		}

		public int size() {
			return this.size;
		}
		// end constructor

		public void add(E element) {
			// add to the end of linked list
			linkLast(element);
		}

		public void add(E element, int a) {
			// add to the middle of linked list
			linkMiddle(element, a);
		}

		private void linkLast(E e) {
			final Node<E> last = this.last;
			final Node<E> newNode = new Node<>(last, e, null);
			if (last == null) {
				this.first = newNode;
			} else
				last.next = newNode;
			this.last = newNode;
			this.size++;
		}

		private void linkMiddle(E e, int a) {
			final Node<E> oldNode = node(a);
			final Node<E> preNode = node(a).prev;
			final Node<E> newNode = new Node<>(preNode, e, oldNode);
			if (a == this.size) {
				linkLast(e);
			} else if (this.first == null)
				this.first = newNode;
			this.size++;
		}

		public E get(int index) throws Exception {
			checkElementIndex(index);
			return node(index).item;
		}

		// find node from index
		private Node<E> node(int index) {
			// beginning at head
			if (index < (this.size / 2)) {

				Node<E> node = this.first;
				for (int i = 0; i < index; i++)
					node = node.next;
				return node;
			} else {
				// beginning at tail
				Node<E> node = this.last;
				for (int i = this.size - 1; i > index; i--)
					node = node.prev;
				return node;
			}
		}

		// set value to the node
		public E set(int index, E element) throws Exception {
			checkElementIndex(index);
			Node<E> node = node(index);
			E old = node.item;
			node.item = element;
			return old;
		}

		public E remove(int index) throws Exception {
			checkElementIndex(index);
			// find node from index and remove it
			return unlink(node(index));
		}

		public int indexOf(E e) throws IOException {
			Node<E> node = this.first;
			for (int i = 0; i < this.size; i++) {
				if (node.item.equals(e))
					return i;
				node = node.next;
			}
			return -1;
		}// end of indexOf()

		public Node<E> nodeOf(E e) throws IOException {
			Node<E> node = this.first;
			for (int i = 0; i < this.size; i++) {
				if (node.item.equals(e))
					return node;
				node = node.next;
			}
			throw new IOException();
		}// end of nodeOf()

		// remove link of the node
		E unlink(Node<E> e) {

			final E element = e.item;
			final Node<E> next = e.next;
			final Node<E> prev = e.prev;

			// if it is the first node
			if (prev == null) {
				this.first = next;
				if (next != null)
					next.prev = null;
			}
			// if it is the last node
			else if (next == null) {
				last = prev;
				prev.next = null;
			}
			// if it is in the middle
			else {
				prev.next = next;
				next.prev = prev;
			}
			this.size--;
			return element;
		}

		public void checkElementIndex(int index) throws Exception {
			if (index < 0) {
				throw new IllegalArgumentException("Index can not be negative.");
			} else if (index >= this.size) {
				throw new IndexOutOfBoundsException("Out of bounds.");
			}
		}

		@SuppressWarnings("hiding")
		private class Node<E> {
			E item;// data of current node
			Node<E> next;
			Node<E> prev;

			Node(Node<E> prev, E element, Node<E> next) {
				this.item = element;
				this.next = next;
				this.prev = prev;
			}
		}
	}// end of class MyLinkedList

} // end of class AdjList
