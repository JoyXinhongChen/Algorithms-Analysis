package assignment1;

import java.io.*;
import java.util.*;

/**
 * this class is to generator the data from random 8 characters for 8 vertex
 * name and 2 bits decimal number for weight(0-99) for three level
 * 1000/1000*1000 2000/1000*1000 5000/1000*1000 density files Generate 300
 * operation sets for every scenario
 * 
 * @author Yi Weng
 *
 */
public class Generation {
	private static File low = new File("low.csv");
	private static File med = new File("med.csv");
	private static File high = new File("high.csv");

	public static void main(String[] args) {
		genGraph();
		genOperation(low);
	}

	public static void genOperation(File file) {
		String[] split = null;
		ArrayList<String> srcs = new ArrayList<String>();
		ArrayList<String> tars = new ArrayList<String>();
		ArrayList<String> weights = new ArrayList<String>();
		try {
			BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(file)));
			File scenario1_1 = new File("scenario1_1.in");
			File scenario1_2 = new File("scenario1_2.in");

			File scenario2 = new File("scenario2.in");
			File scenario3 = new File("scenario3.in");
			String line;
			// read source and target from file
			while ((line = br.readLine()) != null) {
				split = line.split(",");
				srcs.add(split[0]);
				tars.add(split[1]);
				weights.add(split[2]);
			}
			br.close();
			OutputStream s1_1 = new FileOutputStream(scenario1_1);
			OutputStream s1_2 = new FileOutputStream(scenario1_2);

			OutputStream s2 = new FileOutputStream(scenario2);
			OutputStream s3 = new FileOutputStream(scenario3);
			Random random = new Random();
			// build the scenario 1 operator file
			int i = 0;
			String content = "";
			ArrayList<String> conList = new ArrayList<String>();
			// build the scenario 1 operator file
			// remove 300 vertexs
			while (i < 300) {
				int vert = random.nextInt(srcs.size());
				line = "RV " + srcs.get(vert) + "\n";
				if (!conList.contains(line)) {
					content += line;
					conList.add(line);
					i++;
				}
			}
			s1_1.write(content.getBytes());
			s1_1.flush();
			content = "";
			i = 0;
			conList = new ArrayList<String>();
			// remove 300 edges
			while (i < 300) {
				int vert = random.nextInt(srcs.size());
				line = "U " + srcs.get(vert) + " " + tars.get(vert) + " 0" + "\n";
				if (!conList.contains(line)) {
					content += line;
					conList.add(line);
					i++;
				}
			}
			s1_2.write(content.getBytes());
			s1_2.flush();
			content = "";
			i = 0;
			conList = new ArrayList<String>();
			// build the scenario 2 and 3 operator file
			while (i < 300) {
				int vert = random.nextInt(srcs.size());
				int k = 0;

				while (k == 0)
					k = random.nextInt(20) - 1;
				line = "IN " + k + " " + srcs.get(vert) + "\n";

				if (!conList.contains(line)) {
					content += line;
					conList.add(line);
					i++;
				}
				// shuffle again find ON value
				vert = random.nextInt(srcs.size());
				k = 0;
				while (k == 0)
					k = random.nextInt(20) - 1;
				line = "ON " + k + " " + srcs.get(vert) + "\n";

				if (!conList.contains(line)) {
					content += line;
					conList.add(line);
					i++;
				}
			}
			s2.write(content.getBytes());
			s2.flush();
			i = 0;
			content = "";
			conList = new ArrayList<String>();

			// update 300 edges
			while (i < 300) {
				int vert = random.nextInt(srcs.size());
				line = "U " + srcs.get(vert) + " " + tars.get(vert) + " " + (random.nextInt(98) + 1) + "\n";
				if (!conList.contains(line)) {
					content += line;
					conList.add(line);
					i++;
				}
			}
			s3.write(content.getBytes());
			s3.flush();

			s1_1.write("Q".getBytes());
			s1_1.flush();
			s1_1.close();

			s1_2.write("Q".getBytes());
			s1_2.flush();
			s1_2.close();

			s2.write("Q".getBytes());
			s2.flush();
			s2.close();

			s3.write("Q".getBytes());
			s3.flush();
			s3.close();

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static void genGraph() {
		try {

			OutputStream s1 = new FileOutputStream(low);
			OutputStream s2 = new FileOutputStream(med);
			OutputStream s3 = new FileOutputStream(high);

			String line = "";
			Random random = new Random();

			int i = 0;
			// my string characters
			String str = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
			// define the length of vertex name is 8
			int length = 8;
			ArrayList<String> a = new ArrayList<>();
			// use random vertex to build new 1000 vertex into three density level
			while (i < 1000) {
				String vert = "";
				for (int j = 0; j < length; j++)
				// pick random number
				{
					int number = random.nextInt(str.length());
					vert += str.charAt(number);
				}
				if (a.contains(line))
					continue;
				a.add(vert);
				i++;
			}

			i = 0;
			// add another 1000 edge to build low density file
			String src = "";
			String tar = "";
			ArrayList<String> b = new ArrayList<>();
			while (i < 1000) {
				for (int j = 0; j < length; j++)
				// pick random vert
				{
					int number = random.nextInt(a.size());
					src = a.get(number);
				}
				for (int j = 0; j < length; j++) {
					int number = random.nextInt(a.size());
					tar = a.get(number);
				}
				line = src + "," + tar + "," + random.nextInt(99) + "\n";
				if (b.contains(line))
					continue;
				b.add(line);
				s1.write(line.getBytes());
				s1.flush();
				s2.write(line.getBytes());
				s2.flush();
				s3.write(line.getBytes());
				s3.flush();
				i++;
			}

			s1.close();
			// add another 2000 edge to build medium density file
			while (i < 2000) {
				for (int j = 0; j < length; j++)
				// pick random vert
				{
					int number = random.nextInt(a.size());
					src = a.get(number);
				}
				for (int j = 0; j < length; j++) {
					int number = random.nextInt(a.size());
					tar = a.get(number);
				}
				line = src + "," + tar + "," + random.nextInt(99) + "\n";
				if (b.contains(line))
					continue;
				b.add(line);
				s2.write(line.getBytes());
				s2.flush();
				s3.write(line.getBytes());
				s3.flush();
				i++;
			}

			s2.close();
			// add another 5000 edge to build high density file
			while (i < 5000) {
				for (int j = 0; j < length; j++)
				// pick random vert
				{
					int number = random.nextInt(a.size());
					src = a.get(number);
				}
				for (int j = 0; j < length; j++) {
					int number = random.nextInt(a.size());
					tar = a.get(number);
				}
				line = src + "," + tar + "," + random.nextInt(99) + "\n";
				if (b.contains(line))
					continue;
				b.add(line);
				s3.write(line.getBytes());
				s3.flush();
				i++;
			}
			s3.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}