package pathFinder;

import map.Coordinate;
import map.PathMap;

import java.io.IOException;
import java.util.*;

public class DijkstraPathFinder implements PathFinder {
	// TODO: You might need to implement some attributes

	private PathMap map;
	private PriorityQueue<MyPath> paths;
	private List<Coordinate> settled;
	private final int distances[][];
	// define a big number 10000000 as unreachable distance
	private static final int unreachable = 10000000;
	// record every edges of waypoints and source and destination, index is the
	// order of waypoint from map.
	// 0 position is source, n is destination
	private final int wayPointDistances[][];
	private PriorityQueue<MyCoordinate> queueS;

	public DijkstraPathFinder(PathMap map) {

		this.map = map;
		// it means the distance is infinity
		this.distances = new int[this.map.sizeR][this.map.sizeC];
		this.wayPointDistances = new int[this.map.waypointCells.size() + 2][this.map.waypointCells.size() + 2];
		this.paths = new PriorityQueue<MyPath>(myComparator);

	} // end of DijkstraPathFinder()

	@Override
	public List<Coordinate> findPath() {
		List<Coordinate> path = new ArrayList<Coordinate>();
		try {
			for (Coordinate or : this.map.originCells) {

				for (Coordinate de : this.map.destCells) {
					MyPath pa;
					List<Coordinate> pat = new ArrayList<Coordinate>();

					System.out.println(or.toString());
					System.out.println(de.toString());
					if (this.map.waypointCells.size() > 0) {
						if ((pa = wayPointPath(or, de)).path.size() != 0) {
							this.paths.add(pa);
						}
					} else {
						if ((pat = Dijkstra(or, de)).size() != 0) {
							pa = new MyPath(pat, this.distances[de.getRow()][de.getColumn()]);
							this.paths.add(pa);
						}
					}
				}
			}
			/*
			 * find the shortest path between paths(multiple sources and destinations)
			 */
			path = this.paths.peek().path;
			this.settled = new ArrayList<Coordinate>();
			this.settled.addAll(path);

		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
		return path;

	} // end of findPath()

	// find the shortest path through the way point from this origin to destination
	private MyPath wayPointPath(Coordinate or, Coordinate de) throws IOException {
		// record the way point from map
		List<Coordinate> wayPointList = new ArrayList<Coordinate>();
		for (Coordinate point : this.map.waypointCells)
			wayPointList.add(point);
		List<Coordinate> pa = null;
		Coordinate point = null;

		pa = shortestPointPath(or, de, wayPointList);
		List<Coordinate> path = new ArrayList<Coordinate>();

		int distance = 0;
		// get path
		for (int i = 0; i < pa.size() - 1; i++) {
			or = pa.get(i);
			point = pa.get(i + 1);
			List<Coordinate> pat = Dijkstra(or, point);
			distance += this.distances[point.getRow()][point.getColumn()];
			pat.remove(pat.size() - 1);
			path.addAll(pat);
		}
		path.add(de);
		return new MyPath(path, distance);
	}// end of wayPointPath()

	// find the shortest way point path greedily
	private List<Coordinate> shortestPointPath(Coordinate or, Coordinate de, List<Coordinate> wayPointList)
			throws IOException {
		// record the path
		List<Coordinate> order = new ArrayList<Coordinate>();
		// add origin
		order.add(or);
		makeWayPointDistances(or, de);
		while (wayPointList.size() > 0) {
			int minDistance = unreachable;
			Coordinate wayPoint = null;
			for (Coordinate point : wayPointList) {
				int distance = this.distances[point.getRow()][point.getColumn()];
				if (distance == unreachable)
					throw new IOException("(" + point.getRow() + "," + point.getColumn() + ") is impassible");
				if (distance < minDistance) {
					wayPoint = point;
				}
			}
			or = wayPoint;
			// add origin
			order.add(or);
			wayPointList.remove(wayPoint);
		}
		// add destination
		order.add(de);
		return optTwo(order);
	}// end of shortestPointPath()

	private void makeWayPointDistances(Coordinate or, Coordinate de) {
		List<Coordinate> wayPointList = new ArrayList<Coordinate>();
		wayPointList.add(0, or);
		wayPointList.addAll(this.map.waypointCells);
		wayPointList.add(de);
		// record the distance in wayPointDistances
		for (int i = 0; i < this.wayPointDistances.length; i++) {
			Dijkstra(wayPointList.get(i), null);
			for (int j = 0; j < this.wayPointDistances[0].length; j++) {
				int distance = this.distances[wayPointList.get(j).getRow()][wayPointList.get(j).getColumn()];
				this.wayPointDistances[i][j] = distance;
			}
		}
	}// end of makeWayPointDistances()

	// Look for an improvement obtained by deleting two edges and adding two edges.
	private List<Coordinate> optTwo(List<Coordinate> wayPointOrder) {
		int count = 0;
		do {
			count = 0;
			// Look for an improvement obtained by deleting two edges and adding two edges.
			for (int i = 0; i < wayPointOrder.size() - 3; i++) {
				for (int j = i + 2; j < wayPointOrder.size() - 1; j++) {
					int index1 = this.map.waypointCells.indexOf(wayPointOrder.get(i)) + 1;
					if (i == 0)
						index1 = 0;
					int index2 = this.map.waypointCells.indexOf(wayPointOrder.get(i + 1)) + 1;
					int index3 = this.map.waypointCells.indexOf(wayPointOrder.get(j)) + 1;
					int index4 = -1;
					// visit the last one - destination
					if (j + 1 == wayPointOrder.size() - 1)
						index4 = this.wayPointDistances.length - 1;
					else
						index4 = this.map.waypointCells.indexOf(wayPointOrder.get(j + 1)) + 1;
					if (this.wayPointDistances[index1][index2]
							+ this.wayPointDistances[index3][index4] > this.wayPointDistances[index1][index3]
									+ this.wayPointDistances[index2][index4]) {
						count++;
						wayPointOrder = swap(wayPointOrder, i, i + 1, j, j + 1);
					}
				}
			}
		} while (count != 0);
		return wayPointOrder;
	}// end of optTwo()

	// Deleting arcs (index1,index2) and (index3, index4) flips the subpath from
	// index3 to index2 -> like (index1,index3) and (index2, index4)
	private List<Coordinate> swap(List<Coordinate> wayPointOrder, int index1, int index2, int index3, int index4) {
		List<Coordinate> wayPointOrderNew = new ArrayList<Coordinate>();
		wayPointOrderNew.addAll(wayPointOrder.subList(0, index1 + 1));
		for (int i = index3, j = index2; i >= index2; i--, j++) {
			wayPointOrderNew.add(j, wayPointOrder.get(i));
		}
		wayPointOrderNew.addAll(wayPointOrder.subList(index4, wayPointOrder.size()));
		return wayPointOrderNew;
	}// end of swap()

	// find the shortest path directly from a origin to a destination
	private List<Coordinate> Dijkstra(Coordinate or, Coordinate de) {
		List<Coordinate> path = new ArrayList<Coordinate>();

		// initialize the distance of each cells to source to infinity
		for (int i = 0; i < this.distances.length; i++) {
			for (int j = 0; j < this.distances[i].length; j++) {
				this.distances[i][j] = unreachable;
			}
		}
		this.distances[or.getRow()][or.getColumn()] = 0;
		// add origin cell into path
		// relax from source vertex to the destination
		relax(or, de);
		if (de != null)
			path = findBackWay(de, or);
		return path;
	}// end of Dijkstra()

	// relax from the source point to there is no closer neighbour
	private void relax(Coordinate or, Coordinate de) {
		// initialize priority queue
		this.queueS = new PriorityQueue<MyCoordinate>(myCoComparator);
		// the sources for every next neighbour
		this.queueS.add(new MyCoordinate(or, 0));
		boolean flag = true;
		// finish when there is not any next shorter neighbour
		while (flag == true) {
			Coordinate source = this.queueS.poll().coordinate;
			// relax the shortest vertex
			neighbour(source);
			// find the go through all paths
			if (this.queueS.isEmpty())
				flag = false;
			else if (de != null && de == source)
				flag = false;
		}
	}// end of relax()

	// find the neighbour with shorter distance
	private void neighbour(Coordinate or) {
		int i = or.getRow();
		int j = or.getColumn();
		// check the neighbour distance, if the distance shorter than the record,
		// and replace it
		if (this.map.isPassable(i, j - 1)
				&& (this.distances[i][j - 1] > this.distances[i][j] + this.map.cells[i][j - 1].getTerrainCost())) {
			if (!queueS.contains(new MyCoordinate(this.map.cells[i][j - 1], this.distances[i][j - 1])))
				queueS.add(new MyCoordinate(this.map.cells[i][j - 1],
						this.distances[i][j] + this.map.cells[i][j - 1].getTerrainCost()));
			else {
				for (MyCoordinate myco : queueS) {
					if (myco == new MyCoordinate(this.map.cells[i][j - 1], this.distances[i][j - 1]))
						myco.distance = this.distances[i][j] + this.map.cells[i][j - 1].getTerrainCost();
				}
			}
			this.distances[i][j - 1] = this.distances[i][j] + this.map.cells[i][j - 1].getTerrainCost();
		}
		if (this.map.isPassable(i, j + 1)
				&& (this.distances[i][j + 1] > this.distances[i][j] + this.map.cells[i][j + 1].getTerrainCost())) {
			if (!queueS.contains(new MyCoordinate(this.map.cells[i][j + 1], this.distances[i][j + 1])))
				queueS.add(new MyCoordinate(this.map.cells[i][j + 1],
						this.distances[i][j] + this.map.cells[i][j + 1].getTerrainCost()));
			else {
				for (MyCoordinate myco : queueS) {
					if (myco == new MyCoordinate(this.map.cells[i][j + 1], this.distances[i][j + 1]))
						myco.distance = this.distances[i][j] + this.map.cells[i][j + 1].getTerrainCost();
				}
			}
			this.distances[i][j + 1] = this.distances[i][j] + this.map.cells[i][j + 1].getTerrainCost();
		}
		if (this.map.isPassable(i - 1, j)
				&& (this.distances[i - 1][j] > this.distances[i][j] + this.map.cells[i - 1][j].getTerrainCost())) {
			if (!queueS.contains(new MyCoordinate(this.map.cells[i - 1][j], this.distances[i - 1][j])))
				queueS.add(new MyCoordinate(this.map.cells[i - 1][j],
						this.distances[i][j] + this.map.cells[i - 1][j].getTerrainCost()));
			else {
				for (MyCoordinate myco : queueS) {
					if (myco == new MyCoordinate(this.map.cells[i - 1][j], this.distances[i - 1][j]))
						myco.distance = this.distances[i][j] + this.map.cells[i - 1][j].getTerrainCost();
				}
			}
			this.distances[i - 1][j] = this.distances[i][j] + this.map.cells[i - 1][j].getTerrainCost();
		}
		if (this.map.isPassable(i + 1, j)
				&& (this.distances[i + 1][j] > this.distances[i][j] + this.map.cells[i + 1][j].getTerrainCost())) {
			if (!queueS.contains(new MyCoordinate(this.map.cells[i + 1][j], this.distances[i + 1][j])))
				queueS.add(new MyCoordinate(this.map.cells[i + 1][j],
						this.distances[i][j] + this.map.cells[i + 1][j].getTerrainCost()));
			else {
				for (MyCoordinate myco : queueS) {
					if (myco == new MyCoordinate(this.map.cells[i + 1][j], this.distances[i + 1][j]))
						myco.distance = this.distances[i][j] + this.map.cells[i + 1][j].getTerrainCost();
				}
			}
			this.distances[i + 1][j] = this.distances[i][j] + this.map.cells[i + 1][j].getTerrainCost();
		}
	}// end of neighbour()

	private ArrayList<Coordinate> findBackWay(Coordinate de, Coordinate or) {
		ArrayList<Coordinate> path = new ArrayList<Coordinate>();
		int i = de.getRow();
		int j = de.getColumn();

		// if the distance is infinity return null
		if (this.distances[i][j] == unreachable)
			return path;

		path.add(de);
		// go back the shortest path by distance
		for (int dis = this.distances[i][j]; dis != 0;) {
			int index = -1;
			if (this.map.isPassable(i, j - 1) && this.distances[i][j - 1] < dis) {
				dis = this.distances[i][j - 1];
				index = 1;
			}
			if (this.map.isPassable(i, j + 1) && this.distances[i][j + 1] < dis) {
				dis = this.distances[i][j + 1];
				index = 2;
			}
			if (this.map.isPassable(i - 1, j) && this.distances[i - 1][j] < dis) {
				dis = this.distances[i - 1][j];
				index = 3;
			}
			if (this.map.isPassable(i + 1, j) && this.distances[i + 1][j] < dis) {
				dis = this.distances[i + 1][j];
				index = 4;
			}
			// according to index, find the neighbour which has the shortest distance to the
			// source
			if (index == -1)
				break;
			else if (index == 1)
				j = j - 1;
			else if (index == 2)
				j = j + 1;
			else if (index == 3)
				i = i - 1;
			else if (index == 4)
				i = i + 1;
			path.add(0, this.map.cells[i][j]);
		}
		return path;
	}// end of findBackWay()

	@Override
	public int coordinatesExplored() {
		if (this.settled.size() != 0)
			return this.settled.size();
		// placeholder
		return 0;
	} // end of cellsExplored()

	public static Comparator<MyPath> myComparator = new Comparator<MyPath>() {

		@Override
		public int compare(MyPath c1, MyPath c2) {
			return (int) (c1.distance - c2.distance);
		}
	};

	public static Comparator<MyCoordinate> myCoComparator = new Comparator<MyCoordinate>() {

		@Override
		public int compare(MyCoordinate c1, MyCoordinate c2) {
			return (int) (c1.distance - c2.distance);
		}
	};

} // end of class DijsktraPathFinder

// path and its distance
class MyPath {
	public List<Coordinate> path;
	public int distance;

	public MyPath(List<Coordinate> path, int distance) {
		this.path = path;
		this.distance = distance;
	}

}// end of class MyPath

// coordinate and its distance
class MyCoordinate {
	public Coordinate coordinate;
	public int distance;

	public MyCoordinate(Coordinate coordinate, int distance) {
		this.coordinate = coordinate;
		this.distance = distance;
	}
} // end of class MyCoordinate
